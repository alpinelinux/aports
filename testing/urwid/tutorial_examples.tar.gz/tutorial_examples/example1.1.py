#!/usr/bin/python

import urwid

txt = urwid.Text("Hello World")
fill = urwid.Filler(txt, 'top')
loop = urwid.MainLoop(fill)
loop.run()
